using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore.Sqlite;


namespace socrr
{
    class Animal
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string? Especie { get; set; }
        public string? Raca { get; set; }
        public string? Idade { get; set; }
        public string? Dono { get; set; }
    }

    class Database : DbContext
    {
        public Database(DbContextOptions options) : base(options) { }
        public DbSet<Animal> Animais { get; set; } = null!;
        
    }

    class Program
    {
        static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddDbContext<Database>(options => options.UseSqlite(builder.Configuration.GetConnectionString("Database") ?? "Data Source=Database.db"));

            builder.Services.AddCors();

            var app = builder.Build();

            app.UseCors(builder => builder
                .AllowAnyOrigin()
                .AllowAnyMethod()
                .AllowAnyHeader()
            );

            using (var scope = app.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                var context = services.GetRequiredService<Database>();
                context.Database.EnsureCreated();
            }

            app.MapGet("/Animais", (Database database) =>
            {
                return database.Animais.ToList();
            });

            app.MapPost("/Animais", (Database database, Animal animal) =>
            {
                database.Animais.Add(animal);
                database.SaveChanges();
                return Results.Ok();
            });

            app.MapGet("/Animais/{id}", (Database database, int id) =>
            {
                return database.Animais.Find(id);
            });

            app.MapPut("/Animais/{id}", (Database database, Animal updatedAnimal, int id) =>
            {
                var animal = database.Animais.Find(id);
                if (animal == null)
                {
                    return Results.NotFound();
                }
                animal.Nome = updatedAnimal.Nome;
                animal.Especie = updatedAnimal.Especie;
                animal.Raca = updatedAnimal.Raca;
                animal.Idade = updatedAnimal.Idade;
                animal.Dono = updatedAnimal.Dono;
                database.SaveChanges();
                return Results.Ok();
            });

            app.MapDelete("/Animais/{id}", (Database database, int id) =>
            {
                var animal = database.Animais.Find(id);
                if (animal == null)
                {
                    return Results.NotFound();
                }
                database.Remove(animal);
                database.SaveChanges();
                return Results.Ok();
            });

            app.Run("http://localhost:5278");
        }
    }
}
