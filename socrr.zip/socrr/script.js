var url = 'http://localhost:5278/';

function cadastrar() {
    // Validação de alguns dos inputs...

    // Construção do JSON que vai no body da criação de um animal
    let body = {
        'Nome': document.getElementById('nome-animal').value,
        'Especie': document.getElementById('especie').value,
        'Raca': document.getElementById('raca').value,
        'Idade': document.getElementById('idade').value,
        'Dono': document.getElementById('dono').value
    };

    // Envio da requisição usando a FETCH API
    fetch(url + "animais", {
        'method': 'POST',
        'redirect': 'follow',
        'headers': {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        'body': JSON.stringify(body)
    })
    .then((response) => {
        if (response.ok) {
            return response.text();
        } else {
            return response.text().then((text) => {
                throw new Error(text);
            });
        }
    })
    .then((output) => {
        console.log(output);
        alert('Cadastro de animal efetuado! :D');
    })
    .catch((error) => {
        console.log(error);
        alert('Não foi possível efetuar o cadastro do animal! :(');
    });
}

function listar() {
    fetch(url + 'Animais')
    .then(response => response.json())
    .then((animais) => {
        let listaAnimais = document.getElementById('lista-animais');

        while (listaAnimais.firstChild) {
            listaAnimais.removeChild(listaAnimais.firstChild);
        }

        for (let animal of animais) {
            let divAnimal = document.createElement('div');
            divAnimal.setAttribute('class', 'form');

            let divNome = document.createElement('input');
            divNome.placeholder = 'Nome do Animal';
            divNome.value = animal.nome;
            divAnimal.appendChild(divNome);

            let divEspecie = document.createElement('input');
            divEspecie.placeholder = 'Espécie';
            divEspecie.value = animal.especie;
            divAnimal.appendChild(divEspecie);

            let divRaca = document.createElement('input');
            divRaca.placeholder = 'Raça';
            divRaca.value = animal.raca;
            divAnimal.appendChild(divRaca);

            let divIdade = document.createElement('input');
            divIdade.placeholder = 'Idade';
            divIdade.value = animal.idade;
            divAnimal.appendChild(divIdade);

            let divDono = document.createElement('input');
            divDono.placeholder = 'Dono';
            divDono.value = animal.dono;
            divAnimal.appendChild(divDono);

            listaAnimais.appendChild(divAnimal);
        }
    });
}
