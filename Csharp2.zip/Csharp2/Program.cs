using System;
using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace PetShop
{
    // Classe Cliente
    class Cliente
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string? Cpf { get; set; }
        public string? Email { get; set; }
        public string? Telefone { get; set; }
        public DateTime? DataCadastro { get; set; }
    }

    // Classe Funcionario
    class Funcionario
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string? Cargo { get; set; }
        public decimal Salario { get; set; }
        public DateTime? DataContrato { get; set; }
    }

    // Classe Estoque
    class Estoque
    {
        public int Id { get; set; }
        public string? NomeProduto { get; set; }
        public int Quantidade { get; set; }
        public decimal Preco { get; set; }
        public DateTime? DataEntrada { get; set; }
    }

    // Classe Compra
    class Compras
    {
        public int Id { get; set; }
        public int ClienteId { get; set; }
        public int ProdutoId { get; set; }
        public int Quantidade { get; set; }
        public decimal ValorTotal { get; set; }
        public DateTime DataCompra { get; set; }
    }

    // Classe Database
    class Database : DbContext
    {
        public Database(DbContextOptions options) : base(options) { }

        public DbSet<Cliente> Clientes { get; set; } = null!;
        public DbSet<Funcionario> Funcionarios { get; set; } = null!;
        public DbSet<Estoque> Estoques { get; set; } = null!;
        public DbSet<Compras> Compras { get; set; } = null!;
    }

    class Program
    {
        static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Adiciona o banco de dados ao builder
            builder.Services.AddSqlite<Database>(builder.Configuration.GetConnectionString("Database") ?? "Data Source=Database.db");

            // Adiciona a política permissiva de cross-origin ao builder
            builder.Services.AddCors(options => options.AddDefaultPolicy(policy => policy.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

            // Cria a aplicação usando o builder
            var app = builder.Build();

            // Ativa a política de cross-origin
            app.UseCors();

            app.MapGet("/clientes", (Database database) =>
            {
                return database.Clientes.ToList();
            });

            app.MapPost("/clientes", (Database database, Cliente cliente) =>
            {
                // Validações
                if (string.IsNullOrWhiteSpace(cliente.Nome))
                {
                    return Results.BadRequest("O nome do cliente é obrigatório.");
                }

                if (string.IsNullOrWhiteSpace(cliente.Email))
                {
                    return Results.BadRequest("O e-mail do cliente é obrigatório.");
                }

                if (database.Clientes.Any(c => c.Email == cliente.Email))
                {
                    return Results.BadRequest("Já existe um cliente com este e-mail.");
                }

                // Lógica de criação do cliente
                try
                {
                    // Outras validações e lógica podem ser adicionadas conforme necessário
                    cliente.DataCadastro = DateTime.Now;

                    database.Clientes.Add(cliente);
                    database.SaveChanges();

                    return Results.Ok();
                }
                catch (Exception )
                {
                    // Em caso de erro durante a lógica de criação, retorna um erro interno do servidor
                    return Results.Problem("Erro interno do servidor:");
                }
            });

            app.MapGet("/clientes/{id}", (Database database, int id) =>
            {
                return database.Clientes.Find(id);
            });

            app.MapPut("/clientes/{id}", (Database database, Cliente atualizado, int id) =>
            {
                var cliente = database.Clientes.Find(id);
                if (cliente == null)
                {
                    return Results.NotFound();
                }

                // Atualiza propriedades do cliente
                // ...

                database.SaveChanges();
                return Results.Ok();
            });

            app.MapDelete("/clientes/{id}", (Database database, int id) =>
            {
                var cliente = database.Clientes.Find(id);
                if (cliente == null)
                {
                    return Results.NotFound();
                }

                database.Remove(cliente);
                database.SaveChanges();
                return Results.Ok();
            });

            // CRUD Funcionario
            app.MapGet("/funcionarios", (Database database) =>
            {
                return database.Funcionarios.ToList();
            });

            app.MapPost("/funcionarios", (Database database, Funcionario funcionario) =>
            {
                // Validações
                if (string.IsNullOrWhiteSpace(funcionario.Nome))
                {
                    return Results.BadRequest("O nome do funcionário é obrigatório.");
                }

                if (string.IsNullOrWhiteSpace(funcionario.Cargo))
                {
                    return Results.BadRequest("O cargo do funcionário é obrigatório.");
                }

                if (funcionario.Salario < 0)
                {
                    return Results.BadRequest("O salário do funcionário deve ser um valor não negativo.");
                }

                // Lógica de criação do funcionário
                try
                {
                    // Verifica se o salário atende ao mínimo estabelecido
                    decimal salarioMinimo = 1500; // Exemplo de salário mínimo
                    if (funcionario.Salario < salarioMinimo)
                    {
                        return Results.BadRequest($"O salário mínimo para um funcionário é {salarioMinimo}.");
                    }

                    // Adiciona o funcionário ao banco de dados
                    database.Funcionarios.Add(funcionario);
                    database.SaveChanges();

                    return Results.Ok();
                }
                catch (Exception )
                {
                    // Em caso de erro durante a lógica de criação, retorna um erro interno do servidor
                    return Results.Problem("Erro interno do servidor:");
                }
            });

           app.MapGet("/funcionarios/{id}", (Database database, int id) =>
            {
                return database.Funcionarios.Find(id);
            });

            app.MapPut("/funcionarios/{id}", (Database database, Funcionario atualizado, int id) =>
            {
                var funcionario = database.Funcionarios.Find(id);
                if (funcionario == null)
                {
                    return Results.NotFound();
                }

                // Atualiza propriedades do funcionário
                // ...

                database.SaveChanges();
                return Results.Ok();
            });

            app.MapDelete("/funcionarios/{id}", (Database database, int id) =>
            {
                var funcionario = database.Funcionarios.Find(id);
                if (funcionario == null)
                {
                    return Results.NotFound();
                }

                database.Remove(funcionario);
                database.SaveChanges();
                return Results.Ok();
            });

            // CRUD Compra
            app.MapGet("/compras", (Database database) =>
            {
                return database.Compras.ToList();
            });

            app.MapPost("/compras", (Database database, Compras compras) =>
            {
                // Validações
                if (compras.ClienteId <= 0)
                {
                    return Results.BadRequest("O cliente da compra é inválido.");
                }

                if (compras.ProdutoId <= 0)
                {
                    return Results.BadRequest("O produto da compra é inválido.");
                }

                if (compras.Quantidade <= 0)
                {
                    return Results.BadRequest("A quantidade de itens na compra deve ser maior que zero.");
                }

                // Lógica de criação da compra
                try
                {
                    // Verifica se o produto existe no estoque e se há quantidade suficiente
                    var produto = database.Estoques.Find(compras.ProdutoId);
                    if (produto == null || produto.Quantidade < compras.Quantidade)
                    {
                        return Results.BadRequest("Produto indisponível ou quantidade insuficiente no estoque.");
                    }

                    // Obtém o funcionário que está realizando a venda (pode ser passado como parâmetro na requisição)
                    int funcionarioId = 1;
                    var funcionario = database.Funcionarios.Find(funcionarioId);
                    if (funcionario == null)
                    {
                        return Results.BadRequest("Funcionário não encontrado.");
                    }

                    // Atualiza a quantidade de produtos no estoque
                    produto.Quantidade -= compras.Quantidade;

                    // Adiciona informações adicionais à compra
                    compras.ValorTotal = produto.Preco * compras.Quantidade;
                    compras.DataCompra = DateTime.Now;
                    //compras.FuncionarioId = funcionarioId;

                    // Adiciona a compra ao banco de dados
                    database.Compras.Add(compras);
                    database.SaveChanges();

                    return Results.Ok();
                }
                catch (Exception )
                {
                    // Em caso de erro durante a lógica de criação, retorna um erro interno do servidor
                    return Results.Problem("Erro interno do servidor:");
                }
            });

            app.MapGet("/compras/{id}", (Database database, int id) =>
            {
                return database.Compras.Find(id);
            });

            app.MapPut("/compras/{id}", (Database database, Compras atualizada, int id) =>
            {
                var compra = database.Compras.Find(id);
                if (compra == null)
                {
                    return Results.NotFound();
                }

                // Atualiza propriedades da compra
                compra.ClienteId = atualizada.ClienteId;
                compra.ProdutoId = atualizada.ProdutoId;
                compra.Quantidade = atualizada.Quantidade;

                try
                {
                    // Realiza as validações necessárias antes de salvar as alterações
                    database.SaveChanges();
                    return Results.Ok();
                }
                catch (Exception )
                {
                    // Em caso de erro durante a lógica de atualização, retorna um erro interno do servidor
                    return Results.Problem("Erro interno do servidor:");
                }
            });

            app.MapDelete("/compras/{id}", (Database database, int id) =>
            {
                var compra = database.Compras.Find(id);
                if (compra == null)
                {
                    return Results.NotFound();
                }

                database.Remove(compra);
                database.SaveChanges();
                return Results.Ok();
            });

            // CRUD Estoque
            app.MapGet("/estoques", (Database database) =>
            {
                return database.Estoques.ToList();
            });

            app.MapPost("/estoques", (Database database, Estoque produto) =>
            {
                // Validações
                if (string.IsNullOrWhiteSpace(produto.NomeProduto))
                {
                    return Results.BadRequest("O nome do produto é obrigatório.");
                }

                if (produto.Quantidade <= 0)
                {
                    return Results.BadRequest("A quantidade de produtos deve ser maior que zero.");
                }

                if (produto.Preco <= 0)
                {
                    return Results.BadRequest("O preço do produto deve ser maior que zero.");
                }

                // Lógica de criação do produto no estoque
                try
                {
                    // Verifica se o produto já existe no estoque
                    if (database.Estoques.Any(e => e.NomeProduto == produto.NomeProduto))
                    {
                        return Results.BadRequest("Já existe um produto com este nome no estoque.");
                    }

                    // Adiciona o produto ao banco de dados
                    database.Estoques.Add(produto);
                    database.SaveChanges();

                    return Results.Ok();
                }
                catch (Exception )
                {
                    // Em caso de erro durante a lógica de criação, retorna um erro interno do servidor
                    return Results.Problem("Erro interno do servidor:");
                }
            });

            app.MapGet("/estoques/{id}", (Database database, int id) =>
            {
                return database.Estoques.Find(id);
            });

            app.MapPut("/estoques/{id}", (Database database, Estoque atualizado, int id) =>
            {
                var produto = database.Estoques.Find(id);
                if (produto == null)
                {
                    return Results.NotFound();
                }

                // Atualiza propriedades do produto no estoque
                produto.NomeProduto = atualizado.NomeProduto;
                produto.Quantidade = atualizado.Quantidade;
                produto.Preco = atualizado.Preco;

                try
                {
                    // Realiza as validações necessárias antes de salvar as alterações
                    database.SaveChanges();
                    return Results.Ok();
                }
                catch (Exception )
                {
                    // Em caso de erro durante a lógica de atualização, retorna um erro interno do servidor
                    return Results.Problem("Erro interno do servidor:");
                }
            });

            app.MapDelete("/estoques/{id}", (Database database, int id) =>
            {
                var produto = database.Estoques.Find(id);
                if (produto == null)
                {
                    return Results.NotFound();
                }

                database.Remove(produto);
                database.SaveChanges();
                return Results.Ok();
            });

            app.Run("http://localhost:5000");
        }
    }
}